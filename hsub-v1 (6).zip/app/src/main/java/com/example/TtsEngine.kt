package com.example

import android.content.res.AssetManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GeneratedAudio(
    val samples: FloatArray,
    val sampleRate: Int
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as GeneratedAudio
        if (!samples.contentEquals(other.samples)) return false
        if (sampleRate != other.sampleRate) return false
        return true
    }

    override fun hashCode(): Int {
        var result = samples.contentHashCode()
        result = 31 * result + sampleRate
        return result
    }
}

object TtsEngine {
    private const val TAG = "TtsEngine"
    private var ttsInstance: Any? = null
    private var isInitialized = false

    suspend fun loadVoice(modelPath: String, tokensPath: String, dataDirPath: String) = withContext(Dispatchers.IO) {
        try {
            release()
            
            val configClass = try {
                Class.forName("com.k2fsa.sherpa.onnx.OfflineTtsConfig")
            } catch (e: ClassNotFoundException) {
                null
            }

            if (configClass != null) {
                val vitsConfigClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig")
                val vitsConfig = try {
                    vitsConfigClass.getConstructor(
                        String::class.java,
                        String::class.java,
                        String::class.java
                    ).newInstance(modelPath, tokensPath, dataDirPath)
                } catch (e: Exception) {
                    val inst = vitsConfigClass.getConstructor().newInstance()
                    vitsConfigClass.getField("model").set(inst, modelPath)
                    vitsConfigClass.getField("tokens").set(inst, tokensPath)
                    vitsConfigClass.getField("dataDir").set(inst, dataDirPath)
                    inst
                }

                try { vitsConfigClass.getField("noiseScale").set(vitsConfig, 0.667f) } catch (e: Exception) {}
                try { vitsConfigClass.getField("lengthScale").set(vitsConfig, 1.0f) } catch (e: Exception) {}
                try { vitsConfigClass.getField("noiseScaleW").set(vitsConfig, 0.8f) } catch (e: Exception) {}

                val modelConfigClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineTtsModelConfig")
                val modelConfig = modelConfigClass.getConstructor().newInstance()
                modelConfigClass.getField("vits").set(modelConfig, vitsConfig)
                try { modelConfigClass.getField("numThreads").set(modelConfig, 2) } catch (e: Exception) {}
                try { modelConfigClass.getField("debug").set(modelConfig, 1) } catch (e: Exception) {}

                val config = configClass.getConstructor().newInstance()
                configClass.getField("model").set(config, modelConfig)

                val ttsClass = Class.forName("com.k2fsa.sherpa.onnx.OfflineTts")
                ttsInstance = try {
                    val ttsCtor = ttsClass.getConstructor(AssetManager::class.java, configClass)
                    ttsCtor.newInstance(null, config)
                } catch (e: Exception) {
                    ttsClass.getConstructor(configClass).newInstance(config)
                }
                isInitialized = true
                Log.i(TAG, "OfflineTts initialized successfully")
            } else {
                Log.w(TAG, "com.k2fsa.sherpa.onnx.OfflineTts not found on classpath, running in fallback mode")
                isInitialized = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load voice model in TtsEngine", e)
            throw e
        }
    }

    suspend fun synthesize(text: String): GeneratedAudio = withContext(Dispatchers.Default) {
        if (!isInitialized || ttsInstance == null) {
            Log.w(TAG, "TtsEngine not bound to sherpa-onnx instance, generating fallback tone audio")
            return@withContext generateFallbackTone(text)
        }

        try {
            val ttsClass = ttsInstance!!::class.java
            val methods = ttsClass.methods.filter { it.name == "generate" }
            var audioObj: Any? = null

            for (m in methods) {
                try {
                    val params = m.parameterTypes
                    if (params.size == 1 && params[0] == String::class.java) {
                        audioObj = m.invoke(ttsInstance, text)
                        break
                    } else if (params.size == 2 && params[0] == String::class.java && (params[1] == Int::class.javaPrimitiveType || params[1] == java.lang.Integer::class.java)) {
                        audioObj = m.invoke(ttsInstance, text, 0)
                        break
                    } else if (params.size == 3 && params[0] == String::class.java && (params[1] == Int::class.javaPrimitiveType || params[1] == java.lang.Integer::class.java)) {
                        audioObj = m.invoke(ttsInstance, text, 0, 1.0f)
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Method invoke failed for generate variant: ${m.parameterTypes.joinToString()}", e)
                }
            }

            if (audioObj != null) {
                val samplesField = audioObj::class.java.getField("samples")
                val sampleRateField = audioObj::class.java.getField("sampleRate")
                val samples = samplesField.get(audioObj) as FloatArray
                val sampleRate = sampleRateField.getInt(audioObj)
                Log.i(TAG, "Synthesized '${text.take(20)}...' -> ${samples.size} samples, sampleRate=$sampleRate")
                return@withContext GeneratedAudio(samples, sampleRate)
            } else {
                Log.e(TAG, "Could not find or invoke any 'generate' method on $ttsClass")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error synthesizing text with sherpa-onnx OfflineTts: '$text'", e)
        }

        generateFallbackTone(text)
    }

    private fun generateFallbackTone(text: String): GeneratedAudio {
        val sampleRate = 22050
        val durationSeconds = (text.length * 0.08f).coerceAtLeast(0.4f)
        val numSamples = (sampleRate * durationSeconds).toInt()
        val samples = FloatArray(numSamples)
        val freq = 440.0
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            samples[i] = (0.3 * Math.sin(2.0 * Math.PI * freq * t)).toFloat()
        }
        return GeneratedAudio(samples, sampleRate)
    }

    suspend fun release() = withContext(Dispatchers.IO) {
        if (ttsInstance != null) {
            try {
                val releaseMethod = ttsInstance!!::class.java.getMethod("release")
                releaseMethod.invoke(ttsInstance)
            } catch (e: Exception) {
                Log.e(TAG, "Error releasing OfflineTts instance", e)
            }
            ttsInstance = null
        }
        isInitialized = false
    }
}
