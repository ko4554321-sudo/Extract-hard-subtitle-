package com.example

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

// --- Common Data Classes ---
@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null
)

@Serializable
data class GenerationConfig(
    val responseMimeType: String? = "application/json",
    val temperature: Float? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @retrofit2.http.Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; explicitNulls = false }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

@Serializable
data class TranslatedSubtitle(
    val id: Int,
    val text: String
)

object GeminiTranslator {

    private const val TAG = "GeminiTranslator"

    // --- Translation Memory (In-Memory Thread-Safe Cache) ---
    private val translationMemory = ConcurrentHashMap<String, String>()

    // --- Dynamic Entity & Term Synchronizer (Hidden Background Engine) ---
    private val dynamicEntityGlossary = ConcurrentHashMap<String, String>().apply {
        // Characters & Pronouns Lock
        put("师尊", "Sư tôn")
        put("元婴", "Nguyên Anh")
        put("灵石", "Linh thạch")
        put("筑基", "Trúc Cơ")
        put("丹田", "Đan điền")
        put("叶辰", "Diệp Thần")
        put("萧炎", "Tiêu Viêm")
        put("林枫", "Lâm Phong")
        put("楚枫", "Sở Phong")
        put("宗门", "Tông môn")
        put("宗主", "Tông chủ")
        put("师兄", "Sư huynh")
        put("师妹", "Sư muội")
        put("老祖", "Lão tổ")
        put("本座", "Bổn tọa")
        put("朕", "Trẫm")
        put("臣", "Thần")
        put("在下", "Tại hạ")

        // Locations & Sects Lock
        put("云岚宗", "Vân Lam Tông")
        put("沧澜界", "Thương Lan Giới")
        put("极北之地", "Cực Bắc Chi Địa")
        put("丹阁", "Đan Các")
        put("圣地", "Thánh Địa")
        put("中州", "Trung Châu")
        put("凌霄殿", "Lăng Tiêu Điện")

        // Adverbs & Transition Words Lock
        put("突然", "Đột nhiên")
        put("竟然", "Không ngờ")
        put("果然", "Quả nhiên")
        put("必须", "Nhất định")
        put("难道", "Chẳng lẽ")
        put("莫非", "Phải chăng")
        put("无论", "Dù cho")
        put("瞬间", "Trong chớp mắt")
        put("必定", "Chắc chắn")

        // Cultivation & Special Terms Lock
        put("渡劫", "Độ kiếp")
        put("妖兽", "Yêu thú")
        put("仙帝", "Tiên Đế")
        put("神通", "Thần thông")
        put("金丹", "Kim Đan")
        put("斗帝", "Đấu Đế")
        put("功法", "Công pháp")
        put("阵法", "Trận pháp")
        put("异火", "Dị Hỏa")
    }

    private val systemPrompt: String by lazy {
        val glossaryText = dynamicEntityGlossary.entries.joinToString("\n") { "- ${it.key} -> ${it.value}" }
        """
Bạn là một dịch giả phim ảnh chuyên nghiệp Trung-Việt cấp cao, chuyên dịch thoại phim truyền hình, phim điện ảnh và tối ưu hóa đọc thoại cho TTS.

Nhiệm vụ chính: Dịch thoát ý, tự nhiên, chuẩn văn phong điện ảnh Việt Nam như người dịch thủ công chuyên nghiệp, không dịch thô cứng từng từ.

---
HỆ THỐNG ĐỒNG BỘ ẨN - THUẬT NGỮ CỐ ĐỊNH (BACKGROUND ENTITY & TERM LOCK)
$glossaryText

---
Hướng dẫn đồng bộ ngữ cảnh nâng cao:
1. ĐỒNG BỘ NHÂN VẬT & XƯNG HÔ: Đồng bộ tuyệt đối tên nhân vật, danh xưng (anh/em, sư tôn/đồ đệ, bổn tọa, tại hạ...).
2. ĐỒNG BỘ ĐỊA ĐIỂM & TÔNG MÔN: Đồng bộ nhất quán tên địa danh, tông môn, giáo phái, thế lực trong toàn bộ phim.
3. ĐỒNG BỘ TRẠNG TỪ & CẢM THÁC: Giữ văn phong trạng từ tự nhiên (đột nhiên, quả nhiên, không ngờ, chẳng lẽ...), không bị giật cục.
4. ĐỒNG BỘ THUẬT NGỮ PHIM/CÔNG PHÁP: Giữ nguyên thuật ngữ tu tiên, vũ khí, chiêu thức, vật phẩm xuyên suốt.

---
Quy tắc dịch thuật cao cấp:
1. Sửa lỗi OCR Trung Quốc trước khi dịch nếu câu gốc có lỗi gõ/nhận diện.
2. Dịch tự nhiên, mượt mà, sử dụng xưng hô phù hợp ngữ cảnh phim.
3. Thêm chấm phẩy ngắt nghỉ tự nhiên cho giọng đọc thoại.
4. Đảm bảo độ dài tiếng Việt ngắn gọn, vừa vặn với tốc độ nói (maxLength) của từng câu phụ đề.
5. CỰC KỲ QUAN TRỌNG: ĐẢM BẢO TRẢ VỀ ĐỦ 100% TẤT CẢ CÁC ID TRONG DANH SÁCH. KHÔNG ĐƯỢC BỎ SÓT BẤT KỲ ID NÀO!

---
JSON Rules
Trả về duy nhất danh sách JSON hợp lệ:
[
  {
    "id": 1,
    "text": "câu dịch tiếng Việt hoàn chỉnh tự nhiên"
  }
]
        """.trimIndent()
    }

    private val candidateModels = listOf("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.0-flash")

    /**
     * Translates subtitle entries using dynamic smart batching, translation memory,
     * parallel async coroutine execution, and response validation.
     */
    suspend fun translateSubtitles(
        apiKey: String = "",
        model: String = "",
        entries: List<SubtitleEntry>,
        onProgress: (Int, Int) -> Unit
    ): List<SubtitleEntry> = withContext(Dispatchers.IO) {
        val keyToUse = if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            apiKey.trim()
        } else {
            BuildConfig.GEMINI_API_KEY.trim()
        }

        if (keyToUse.isEmpty() || keyToUse == "MY_GEMINI_API_KEY") {
            throw Exception("Chưa tìm thấy Gemini API Key. Vui lòng nhập API Key trong phần Cấu hình.")
        }

        Log.d(TAG, "Translation Started. Total subtitles: ${entries.size}")
        val startTimeMs = System.currentTimeMillis()

        val resultsMap = ConcurrentHashMap<Int, String>()
        val uncompressedEntries = mutableListOf<SubtitleEntry>()

        // Step 1: Check Translation Memory (Cache) first
        var cacheHits = 0
        for (entry in entries) {
            val normalizedSource = entry.text.trim()
            val cached = translationMemory[normalizedSource]
            if (cached != null) {
                resultsMap[entry.index] = cached
                cacheHits++
            } else {
                uncompressedEntries.add(entry)
            }
        }
        Log.d(TAG, "Translation Memory Cache Hits: $cacheHits / ${entries.size}")

        if (uncompressedEntries.isNotEmpty()) {
            val batches = buildSmartBatches(uncompressedEntries, maxBatchChars = 2500)
            Log.d(TAG, "Created ${batches.size} dynamic smart batches for ${uncompressedEntries.size} pending entries")

            val primaryModel = if (model.isNotBlank() && !model.contains("1.5") && !model.contains("2.0-flash-exp")) model else "gemini-flash-latest"
            val modelsToTry = (listOf(primaryModel) + candidateModels).distinct()
            val completedCount = java.util.concurrent.atomic.AtomicInteger(cacheHits)

            val semaphore = Semaphore(4)
            coroutineScope {
                val deferreds = batches.map { batch ->
                    async {
                        semaphore.withPermit {
                            val translatedBatchResults = translateBatchFast(
                                batch = batch,
                                modelsToTry = modelsToTry,
                                apiKey = keyToUse
                            )

                            for ((id, text) in translatedBatchResults) {
                                resultsMap[id] = text
                                val sourceEntry = batch.find { it.index == id }
                                if (sourceEntry != null && sourceEntry.text.isNotBlank()) {
                                    translationMemory[sourceEntry.text.trim()] = text
                                }
                            }

                            val finished = completedCount.addAndGet(batch.size)
                            onProgress(minOf(finished, entries.size), entries.size)
                        }
                    }
                }
                deferreds.awaitAll()
            }
        } else {
            onProgress(entries.size, entries.size)
        }

        val totalDurationMs = System.currentTimeMillis() - startTimeMs
        Log.d(TAG, "Translation Complete in ${totalDurationMs}ms. Memory Cache Size: ${translationMemory.size}")

        val finalEntries = entries.map { entry ->
            val translatedText = resultsMap[entry.index] ?: fallbackTranslateSingleText(entry.text)
            entry.copy(text = translatedText)
        }

        // Validate results (Requirement A3)
        val chineseRegex = Regex("[\\u4E00-\\u9FFF]")
        var untranslatedCount = 0
        for (e in finalEntries) {
            if (chineseRegex.containsMatchIn(e.text)) {
                untranslatedCount++
            }
        }

        if (finalEntries.isNotEmpty() && (untranslatedCount.toDouble() / finalEntries.size.toDouble()) > 0.20) {
            throw Exception("Dịch thất bại: $untranslatedCount / ${finalEntries.size} câu phụ đề vẫn chưa được dịch sang tiếng Việt. Vui lòng kiểm tra lại API Key hoặc mạng.")
        }

        return@withContext finalEntries
    }

    /**
     * Fallback translator for individual untranslated strings using term dictionary replacement.
     */
    private fun fallbackTranslateSingleText(sourceText: String): String {
        var text = sourceText
        for ((cn, vi) in dynamicEntityGlossary) {
            text = text.replace(cn, vi)
        }
        return text
    }

    /**
     * Groups subtitle entries into dynamic batches based on character length.
     */
    private fun buildSmartBatches(entries: List<SubtitleEntry>, maxBatchChars: Int): List<List<SubtitleEntry>> {
        val batches = mutableListOf<List<SubtitleEntry>>()
        var currentBatch = mutableListOf<SubtitleEntry>()
        var currentBatchCharCount = 0

        for (entry in entries) {
            val entryCharCount = entry.text.length + 50 // Overhead per item
            if (currentBatch.isNotEmpty() && (currentBatchCharCount + entryCharCount > maxBatchChars)) {
                batches.add(currentBatch)
                currentBatch = mutableListOf()
                currentBatchCharCount = 0
            }
            currentBatch.add(entry)
            currentBatchCharCount += entryCharCount
        }
        if (currentBatch.isNotEmpty()) {
            batches.add(currentBatch)
        }
        return batches
    }

    /**
     * Translates a single batch cleanly. Attempts models in modelsToTry without deep recursive loops.
     */
    private suspend fun translateBatchFast(
        batch: List<SubtitleEntry>,
        modelsToTry: List<String>,
        apiKey: String
    ): Map<Int, String> {
        if (batch.isEmpty()) return emptyMap()

        val promptBuilder = StringBuilder("Dịch danh sách phụ đề sau sang tiếng Việt (đảm bảo trả đủ ${batch.size} ID):\n")
        for (entry in batch) {
            val durationMs = entry.endTimeMs - entry.startTimeMs
            val maxLength = ((durationMs / 1000.0) * 15).toInt().coerceAtLeast(15)
            promptBuilder.append("ID: ${entry.index} | Duration: ${durationMs}ms | MaxLength: ${maxLength} chars | Text: ${entry.text}\n")
        }

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = promptBuilder.toString())))),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2f
            )
        )

        var lastError: Exception? = null
        for (m in modelsToTry) {
            try {
                Log.d(TAG, "Sending batch (${batch.size} items) to model $m")
                val response = RetrofitClient.service.generateContent(m, apiKey, request)
                val rawText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "[]"

                var jsonStr = rawText
                if (jsonStr.contains("```json")) {
                    jsonStr = jsonStr.substringAfter("```json").substringBeforeLast("```").trim()
                } else if (jsonStr.contains("```")) {
                    jsonStr = jsonStr.substringAfter("```").substringBeforeLast("```").trim()
                }

                val jsonParser = Json { ignoreUnknownKeys = true }
                val parsedArray = jsonParser.decodeFromString<List<TranslatedSubtitle>>(jsonStr)

                if (parsedArray.isNotEmpty()) {
                    val resultMap = mutableMapOf<Int, String>()
                    for (entry in batch) {
                        val translatedObj = parsedArray.find { it.id == entry.index }
                        if (translatedObj != null && translatedObj.text.isNotBlank()) {
                            resultMap[entry.index] = translatedObj.text
                        } else {
                            resultMap[entry.index] = fallbackTranslateSingleText(entry.text)
                        }
                    }
                    Log.d(TAG, "Batch translation succeeded with model $m")
                    return resultMap
                }
            } catch (e: Exception) {
                lastError = e
                Log.w(TAG, "Model $m failed for batch: ${e.message}")
            }
        }

        // Fallback for the batch if API calls fail
        Log.e(TAG, "All API models failed for batch of size ${batch.size}: ${lastError?.message}. Using dictionary fallback.")
        val fallbackMap = mutableMapOf<Int, String>()
        for (entry in batch) {
            fallbackMap[entry.index] = fallbackTranslateSingleText(entry.text)
        }
        return fallbackMap
    }
}
