package com.example

import android.content.Context
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result -> cont.resume(result) }
    addOnFailureListener { exception -> cont.resumeWithException(exception) }
    addOnCanceledListener { cont.cancel() }
}

class VideoProcessor(private val context: Context) {

    private val TAG = "VideoProcessor"
    private val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())

    /**
     * Executes the streaming OCR pipeline using producer-consumer coroutine channels.
     */
    fun processVideo(
        videoUri: Uri,
        cropRect: RectF,
        timelineBuilder: TimelineBuilder
    ): Flow<ProcessingProgress> = flow {
        val retriever = MediaMetadataRetriever()

        try {
            retriever.setDataSource(context, videoUri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val totalTimeMs = durationStr?.toLongOrNull() ?: 0L

            if (totalTimeMs == 0L) {
                Log.e(TAG, "Invalid video duration (0ms). Aborting pipeline.")
                return@flow
            }

            Log.d(TAG, "Starting OCR Pipeline. Video Duration: ${totalTimeMs}ms")
            timelineBuilder.clear()

            val scheduler = AdaptiveFrameScheduler(
                minStepMs = 150L,
                baseStepMs = 250L,
                maxStepMs = 1500L
            )

            // Bounded queue for producer-consumer pipeline (expanded buffer for max throughput)
            val frameChannel = Channel<FramePacket>(capacity = 16)

            var ocrExecutions = 0
            var skippedOcrCalls = 0
            var processedFrames = 0
            val startTimeNano = System.nanoTime()

            var previousHash: Long? = null
            var previousText = ""

            // We run decoding producer in a coroutine and consume frames in flow
            coroutineScope {
                // Producer: Extracts and crops frames asynchronously
                launch(Dispatchers.IO) {
                    var currentTimeMs = 0L
                    var frameNumber = 0

                    try {
                        while (currentTimeMs <= totalTimeMs) {
                            val bitmap = retriever.getFrameAtTime(
                                currentTimeMs * 1000,
                                MediaMetadataRetriever.OPTION_CLOSEST
                            )

                            if (bitmap != null) {
                                // Crop immediately to release full-frame bitmap memory
                                val cropped = ImagePreprocessor.cropAndEnhance(bitmap, cropRect)
                                bitmap.recycle() // Release original large frame immediately

                                val stepMs = scheduler.currentStepMs
                                frameChannel.send(
                                    FramePacket(
                                        frameNumber = frameNumber,
                                        timestampMs = currentTimeMs,
                                        croppedBitmap = cropped,
                                        stepMs = stepMs
                                    )
                                )
                            } else {
                                Log.w(TAG, "Frame decode returned null at ${currentTimeMs}ms")
                            }

                            val step = scheduler.currentStepMs
                            currentTimeMs += step
                            frameNumber++
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Decoder error: ${e.message}", e)
                    } finally {
                        frameChannel.close()
                    }
                }

                // Consumer: Image Comparison, OCR execution, and Timeline accumulation
                for (packet in frameChannel) {
                    processedFrames++
                    val cropped = packet.croppedBitmap

                    val comparison = SubtitleImageComparator.compare(cropped, previousHash)
                    var currentText = ""
                    var wasOcrExecuted = false

                    if (comparison.isIdentical) {
                        // Image visually unchanged -> Skip ML Kit OCR call!
                        skippedOcrCalls++
                        currentText = previousText
                        scheduler.getNextStepMs(isIdentical = true, isBlank = false)
                    } else if (comparison.isBlank) {
                        // Region is blank -> No subtitle
                        skippedOcrCalls++
                        currentText = ""
                        previousText = ""
                        previousHash = comparison.currentHash
                        scheduler.getNextStepMs(isIdentical = false, isBlank = true)
                    } else {
                        // Visual change detected -> Execute ML Kit OCR
                        try {
                            val inputImage = InputImage.fromBitmap(cropped, 0)
                            val textResult = recognizer.process(inputImage).awaitTask()
                            val rawText = textResult.text.replace("\n", " ").trim()

                            if (rawText.isEmpty() && comparison.hammingDistance > 12) {
                                // Low confidence or missed recognition -> Retry with secondary enhancement
                                val secondaryBitmap = ImagePreprocessor.applySecondaryEnhancement(cropped)
                                val secondaryImage = InputImage.fromBitmap(secondaryBitmap, 0)
                                val retryResult = recognizer.process(secondaryImage).awaitTask()
                                currentText = retryResult.text.replace("\n", " ").trim()
                                secondaryBitmap.recycle()
                            } else {
                                currentText = rawText
                            }

                            ocrExecutions++
                            wasOcrExecuted = true
                            previousText = currentText
                            previousHash = comparison.currentHash
                            scheduler.getNextStepMs(isIdentical = false)
                        } catch (e: Exception) {
                            Log.e(TAG, "OCR Error on frame ${packet.frameNumber}: ${e.message}")
                            currentText = previousText // Graceful fallback
                        }
                    }

                    // Recycle cropped bitmap after image processing & OCR
                    cropped.recycle()

                    // Add to timeline builder
                    timelineBuilder.processFrame(
                        frameNumber = packet.frameNumber,
                        timestampMs = packet.timestampMs,
                        stepMs = packet.stepMs,
                        text = currentText,
                        wasOcrExecuted = wasOcrExecuted
                    )

                    // Calculate performance metrics
                    val elapsedSeconds = (System.nanoTime() - startTimeNano) / 1_000_000_000f
                    val fps = if (elapsedSeconds > 0) processedFrames / elapsedSeconds else 0f
                    val processedDurationMs = packet.timestampMs.coerceAtLeast(1L)
                    val realtimeSpeedX = if (elapsedSeconds > 0) (processedDurationMs / 1000f) / elapsedSeconds else 0f
                    val remainingDurationMs = totalTimeMs - packet.timestampMs
                    val estimatedTimeRemainingMs = if (realtimeSpeedX > 0) (remainingDurationMs / realtimeSpeedX).toLong() else 0L

                    val estimatedTotalFrames = (totalTimeMs / scheduler.currentStepMs).toInt().coerceAtLeast(processedFrames)

                    emit(
                        ProcessingProgress(
                            currentFrame = processedFrames,
                            totalFrames = estimatedTotalFrames,
                            currentTimeMs = packet.timestampMs,
                            totalTimeMs = totalTimeMs,
                            textRecognized = currentText,
                            ocrExecutions = ocrExecutions,
                            skippedOcrCalls = skippedOcrCalls,
                            fps = fps,
                            realtimeSpeedX = realtimeSpeedX,
                            estimatedTimeRemainingMs = estimatedTimeRemainingMs,
                            currentStepMs = packet.stepMs
                        )
                    )
                }
            }

            // Finalize open timeline entries
            timelineBuilder.finalizeTimeline()
            Log.d(
                TAG,
                "Pipeline Complete. Processed Frames: $processedFrames, OCR Executions: $ocrExecutions, Skipped: $skippedOcrCalls"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Pipeline Exception: ${e.message}", e)
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }.flowOn(Dispatchers.Default)
}
