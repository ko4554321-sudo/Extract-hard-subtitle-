package com.example

import android.util.Log

class TimelineBuilder {

    private val rawResults = mutableListOf<RawOcrResult>()
    private var activeResult: RawOcrResult? = null

    /**
     * Process incoming OCR or cached frame result into the timeline.
     */
    fun processFrame(
        frameNumber: Int,
        timestampMs: Long,
        stepMs: Long,
        text: String,
        confidence: Float = 1.0f,
        wasOcrExecuted: Boolean = true
    ): RawOcrResult? {
        val cleanText = text.trim()

        if (cleanText.isEmpty()) {
            // Subtitle disappeared from screen -> finalize active subtitle
            val finalized = activeResult
            activeResult = null
            return finalized
        }

        val currentActive = activeResult

        if (currentActive == null) {
            // New subtitle appeared
            val newResult = RawOcrResult(
                frameNumber = frameNumber,
                startTimeMs = timestampMs,
                endTimeMs = timestampMs + stepMs,
                text = cleanText,
                confidence = confidence,
                wasOcrExecuted = wasOcrExecuted
            )
            activeResult = newResult
            rawResults.add(newResult)
            return newResult
        } else {
            // Check if text matches active subtitle
            val textMatches = currentActive.text == cleanText || isTextSimilar(currentActive.text, cleanText)

            if (textMatches) {
                // Extend active subtitle end timestamp
                currentActive.endTimeMs = maxOf(currentActive.endTimeMs, timestampMs + stepMs)
                if (cleanText.length > currentActive.text.length) {
                    // Update text if cleaner/longer version found
                    activeResult = currentActive.copy(text = cleanText)
                    rawResults[rawResults.lastIndex] = activeResult!!
                }
                return activeResult
            } else {
                // Subtitle text changed -> finalize current active subtitle and start new one
                currentActive.endTimeMs = timestampMs
                val newResult = RawOcrResult(
                    frameNumber = frameNumber,
                    startTimeMs = timestampMs,
                    endTimeMs = timestampMs + stepMs,
                    text = cleanText,
                    confidence = confidence,
                    wasOcrExecuted = wasOcrExecuted
                )
                activeResult = newResult
                rawResults.add(newResult)
                return newResult
            }
        }
    }

    /**
     * Call at the end of processing to finalize any remaining open subtitle.
     */
    fun finalizeTimeline(): List<RawOcrResult> {
        activeResult = null
        return rawResults.toList()
    }

    fun clear() {
        rawResults.clear()
        activeResult = null
    }

    private fun isTextSimilar(s1: String, s2: String): Boolean {
        if (s1 == s2) return true
        val c1 = s1.replace(Regex("[\\s\\p{Punct}，。！？、“”‘’：；\\-_\\.]"), "").lowercase()
        val c2 = s2.replace(Regex("[\\s\\p{Punct}，。！？、“”‘’：；\\-_\\.]"), "").lowercase()
        if (c1.isEmpty() || c2.isEmpty()) return c1 == c2
        if (c1 == c2 || c1.contains(c2) || c2.contains(c1)) return true
        return false
    }
}
