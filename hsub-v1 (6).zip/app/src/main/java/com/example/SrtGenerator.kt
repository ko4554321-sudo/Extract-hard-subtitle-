package com.example

import java.util.Locale

object SrtGenerator {

    fun generateEntries(rawResults: List<RawOcrResult>): List<SubtitleEntry> {
        val validResults = rawResults.filter { it.text.isNotBlank() }
        if (validResults.isEmpty()) return emptyList()

        val mergedEntries = mutableListOf<SubtitleEntry>()
        var currentEntry: SubtitleEntry? = null
        var index = 1
        val gapThresholdMs = 1500L

        for (result in validResults) {
            val normalizedText = normalizeText(result.text)
            if (normalizedText.isBlank()) continue

            if (currentEntry == null) {
                currentEntry = SubtitleEntry(index, result.startTimeMs, result.endTimeMs, normalizedText)
            } else {
                val currentClean = cleanForComparison(currentEntry.text)
                val newClean = cleanForComparison(normalizedText)
                val gap = result.startTimeMs - currentEntry.endTimeMs

                val isSimilar = isTextSimilar(currentClean, newClean)

                if (isSimilar && gap < gapThresholdMs) {
                    currentEntry.endTimeMs = maxOf(currentEntry.endTimeMs, result.endTimeMs)
                    if (normalizedText.length > currentEntry.text.length) {
                        currentEntry = currentEntry.copy(text = normalizedText)
                    }
                } else {
                    mergedEntries.add(currentEntry)
                    index++
                    currentEntry = SubtitleEntry(index, result.startTimeMs, result.endTimeMs, normalizedText)
                }
            }
        }
        currentEntry?.let { mergedEntries.add(it) }

        // Second pass merge to combine entries with identical cleaned text across short pauses
        val finalEntries = mutableListOf<SubtitleEntry>()
        var finalIndex = 1
        var tempEntry: SubtitleEntry? = null

        for (entry in mergedEntries) {
            if (tempEntry == null) {
                tempEntry = entry.copy(index = finalIndex)
            } else {
                val tempClean = cleanForComparison(tempEntry.text)
                val entryClean = cleanForComparison(entry.text)
                val gap = entry.startTimeMs - tempEntry.endTimeMs

                if (isTextSimilar(tempClean, entryClean) && gap < gapThresholdMs) {
                    tempEntry.endTimeMs = maxOf(tempEntry.endTimeMs, entry.endTimeMs)
                    if (entry.text.length > tempEntry.text.length) {
                        tempEntry = tempEntry.copy(text = entry.text)
                    }
                } else {
                    finalEntries.add(tempEntry)
                    finalIndex++
                    tempEntry = entry.copy(index = finalIndex)
                }
            }
        }
        tempEntry?.let { finalEntries.add(it) }

        return finalEntries
    }

    private fun cleanForComparison(text: String): String {
        return text.lowercase(Locale.ROOT)
            .replace(Regex("[\\s\\p{Punct}，。！？、“”‘’：；\\-_\\.]"), "")
    }

    private fun isTextSimilar(s1: String, s2: String): Boolean {
        if (s1.isEmpty() || s2.isEmpty()) return s1 == s2
        if (s1 == s2) return true
        if (s1.contains(s2) || s2.contains(s1)) return true

        val dist = levenshteinDistance(s1, s2)
        val maxLength = maxOf(s1.length, s2.length)
        val similarity = 1.0 - (dist.toDouble() / maxLength)
        return similarity >= 0.75
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = IntArray(s2.length + 1) { it }
        for (i in 1..s1.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..s2.length) {
                val temp = dp[j]
                if (s1[i - 1] == s2[j - 1]) {
                    dp[j] = prev
                } else {
                    dp[j] = 1 + minOf(prev, dp[j], dp[j - 1])
                }
                prev = temp
            }
        }
        return dp[s2.length]
    }

    fun entriesToSrt(entries: List<SubtitleEntry>): String {
        val srtBuilder = StringBuilder()
        for (entry in entries) {
            srtBuilder.append(entry.index).append("\n")
            srtBuilder.append(formatTime(entry.startTimeMs)).append(" --> ").append(formatTime(entry.endTimeMs)).append("\n")
            srtBuilder.append(entry.text).append("\n\n")
        }
        return srtBuilder.toString()
    }

    fun generateSrt(rawResults: List<RawOcrResult>): String {
        return entriesToSrt(generateEntries(rawResults))
    }

    fun parseSrt(srtContent: String): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        val blocks = srtContent.trim().split(Regex("(\r?\n){2,}"))
        for (block in blocks) {
            val lines = block.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue

            var id: Int? = null
            var timeLineIndex = -1

            for (i in lines.indices) {
                if (lines[i].contains("-->")) {
                    timeLineIndex = i
                    if (i > 0) {
                        id = lines[i - 1].toIntOrNull()
                    }
                    break
                }
            }

            if (timeLineIndex != -1) {
                val timeLine = lines[timeLineIndex]
                val timeMatch = Regex("(\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3})\\s*-->\\s*(\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3})").find(timeLine)
                if (timeMatch != null) {
                    val startMs = parseTimeToMs(timeMatch.groupValues[1])
                    val endMs = parseTimeToMs(timeMatch.groupValues[2])
                    val textLines = lines.drop(timeLineIndex + 1).joinToString(" ")
                    if (textLines.isNotBlank()) {
                        val entryId = id ?: (entries.size + 1)
                        entries.add(SubtitleEntry(entryId, startMs, endMs, textLines))
                    }
                }
            }
        }
        return entries
    }

    private fun parseTimeToMs(timeStr: String): Long {
        val normalized = timeStr.replace(".", ",")
        val parts = normalized.split(":")
        if (parts.size == 3) {
            val hours = parts[0].toLongOrNull() ?: 0L
            val minutes = parts[1].toLongOrNull() ?: 0L
            val secMs = parts[2].split(",")
            val seconds = secMs[0].toLongOrNull() ?: 0L
            val ms = if (secMs.size > 1) secMs[1].padEnd(3, '0').take(3).toLongOrNull() ?: 0L else 0L
            return hours * 3600000L + minutes * 60000L + seconds * 1000L + ms
        }
        return 0L
    }

    private fun normalizeText(text: String): String {
        return text.replace(Regex("\\s+"), " ")
            .replace("，", ",")
            .replace("。", ".")
            .replace("！", "!")
            .replace("？", "?")
            .trim()
    }

    private fun formatTime(timeMs: Long): String {
        val totalSeconds = timeMs / 1000
        val ms = timeMs % 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, ms)
    }
}
