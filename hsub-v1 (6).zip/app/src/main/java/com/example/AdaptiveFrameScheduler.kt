package com.example

class AdaptiveFrameScheduler(
    val minStepMs: Long = 150L,
    val baseStepMs: Long = 250L,
    val maxStepMs: Long = 1500L
) {
    var currentStepMs: Long = baseStepMs
        private set

    private var consecutiveStaticFrames = 0

    /**
     * Called after evaluating a frame's perceptual image similarity.
     * @param isIdentical True if subtitle image did not change from previous frame.
     * @param isBlank True if subtitle box has no active text.
     * @return Next step size in milliseconds.
     */
    fun getNextStepMs(isIdentical: Boolean, isBlank: Boolean = false): Long {
        if (isBlank) {
            // Region is blank (no dialogue) -> Step quickly through silence
            consecutiveStaticFrames = 0
            currentStepMs = 800L
        } else if (isIdentical) {
            consecutiveStaticFrames++
            // Gradually expand step size when subtitle stays static
            when {
                consecutiveStaticFrames >= 4 -> currentStepMs = maxStepMs
                consecutiveStaticFrames >= 2 -> currentStepMs = 800L
                consecutiveStaticFrames >= 1 -> currentStepMs = 450L
            }
        } else {
            // Subtitle transition detected! Immediately reset step to fine-grain step
            consecutiveStaticFrames = 0
            currentStepMs = minStepMs
        }
        return currentStepMs
    }

    fun reset() {
        consecutiveStaticFrames = 0
        currentStepMs = baseStepMs
    }
}

