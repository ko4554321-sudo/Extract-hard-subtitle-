package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.util.Log

object ImagePreprocessor {

    private const val TAG = "ImagePreprocessor"

    /**
     * Crops the user-selected subtitle rectangle immediately from source bitmap
     * and applies primary image enhancement (Grayscale + Contrast Boost).
     */
    fun cropAndEnhance(source: Bitmap, rectF: RectF): Bitmap {
        val left = (source.width * rectF.left).toInt().coerceIn(0, source.width)
        val top = (source.height * rectF.top).toInt().coerceIn(0, source.height)
        val right = (source.width * rectF.right).toInt().coerceIn(0, source.width)
        val bottom = (source.height * rectF.bottom).toInt().coerceIn(0, source.height)

        val width = (right - left).coerceAtLeast(1)
        val height = (bottom - top).coerceAtLeast(1)

        val cropped = Bitmap.createBitmap(source, left, top, width, height)

        // Apply primary enhancement: High Contrast Grayscale
        val enhanced = applyGrayscaleContrast(cropped, contrast = 1.8f, brightness = -15f)

        if (cropped !== source && !cropped.isRecycled && cropped !== enhanced) {
            cropped.recycle()
        }

        return enhanced
    }

    /**
     * Secondary enhancement pipeline used when OCR confidence is low or initial recognition fails.
     * Applies binarization thresholding / high-contrast sharpening.
     */
    fun applySecondaryEnhancement(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        
        // High contrast + inverted/binarized representation
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()

        // High contrast matrix
        val contrast = 2.5f
        val brightness = -40f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        
        val grayscaleMatrix = ColorMatrix()
        grayscaleMatrix.setSaturation(0f)
        grayscaleMatrix.postConcat(contrastMatrix)

        paint.colorFilter = ColorMatrixColorFilter(grayscaleMatrix)
        canvas.drawBitmap(source, 0f, 0f, paint)

        return result
    }

    private fun applyGrayscaleContrast(source: Bitmap, contrast: Float, brightness: Float): Bitmap {
        val width = source.width
        val height = source.height

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()

        val colorMatrix = ColorMatrix()
        colorMatrix.setSaturation(0f)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        colorMatrix.postConcat(contrastMatrix)

        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(source, 0f, 0f, paint)

        return result
    }
}
