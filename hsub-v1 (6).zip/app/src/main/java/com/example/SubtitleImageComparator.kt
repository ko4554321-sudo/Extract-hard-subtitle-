package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log

object SubtitleImageComparator {

    private const val TAG = "SubtitleImageComparator"

    // Hamming distance threshold: <= 8 out of 64 bits considered visually identical subtitle image
    private const val SIMILARITY_THRESHOLD = 8

    data class ComparisonResult(
        val isIdentical: Boolean,
        val isBlank: Boolean,
        val currentHash: Long,
        val hammingDistance: Int
    )

    /**
     * Compares the cropped subtitle bitmap against the previous hash.
     * Executes BEFORE OCR to decide if ML Kit call can be skipped entirely.
     */
    fun compare(
        currentBitmap: Bitmap,
        previousHash: Long?
    ): ComparisonResult {
        val currentHash = calculateDHash(currentBitmap)
        val isBlank = isImageBlank(currentBitmap)

        if (previousHash == null) {
            return ComparisonResult(
                isIdentical = false,
                isBlank = isBlank,
                currentHash = currentHash,
                hammingDistance = 64
            )
        }

        val distance = java.lang.Long.bitCount(currentHash xor previousHash)
        val isIdentical = distance <= SIMILARITY_THRESHOLD

        return ComparisonResult(
            isIdentical = isIdentical,
            isBlank = isBlank,
            currentHash = currentHash,
            hammingDistance = distance
        )
    }

    /**
     * Calculates 64-bit Difference Hash (dHash) for fast perceptual comparison.
     */
    fun calculateDHash(bitmap: Bitmap): Long {
        val scaled = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        var hash = 0L

        for (y in 0 until 8) {
            for (x in 0 until 8) {
                val pixelLeft = scaled.getPixel(x, y)
                val pixelRight = scaled.getPixel(x + 1, y)

                val lLeft = (Color.red(pixelLeft) * 299 + Color.green(pixelLeft) * 587 + Color.blue(pixelLeft) * 114) / 1000
                val lRight = (Color.red(pixelRight) * 299 + Color.green(pixelRight) * 587 + Color.blue(pixelRight) * 114) / 1000

                if (lLeft > lRight) {
                    hash = hash or (1L shl (y * 8 + x))
                }
            }
        }

        scaled.recycle()
        return hash
    }

    /**
     * Fast check to detect if the cropped subtitle region is completely blank/black (no text).
     */
    private fun isImageBlank(bitmap: Bitmap): Boolean {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= 0 || height <= 0) return true

        val sampleStepX = maxOf(1, width / 10)
        val sampleStepY = maxOf(1, height / 5)

        var totalLuminance = 0L
        var sampleCount = 0

        for (y in 0 until height step sampleStepY) {
            for (x in 0 until width step sampleStepX) {
                val pixel = bitmap.getPixel(x, y)
                val lum = (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000
                totalLuminance += lum
                sampleCount++
            }
        }

        if (sampleCount == 0) return true
        val avgLuminance = totalLuminance / sampleCount
        // Very low average luminance indicates blank/dark background without active bright text
        return avgLuminance < 12
    }
}
