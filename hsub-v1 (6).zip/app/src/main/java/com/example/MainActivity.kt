package com.example

import android.content.Context
import android.content.Intent
import android.graphics.RectF
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileWriter

class MainActivity : ComponentActivity() {

    private val viewModel: HSubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    HSubScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding),
                        context = this
                    )
                }
            }
        }
    }
}

@Composable
fun HSubScreen(
    viewModel: HSubViewModel,
    modifier: Modifier = Modifier,
    context: Context
) {
    val appState by viewModel.appState.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val videoUri by viewModel.videoUri.collectAsState()
    val previewBitmap by viewModel.previewBitmap.collectAsState()
    val srtContent by viewModel.srtContent.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()
    val translationProgress by viewModel.translationProgress.collectAsState()

    val ttsModelReady by viewModel.ttsModelReady.collectAsState()
    val isSynthesizing by viewModel.isSynthesizing.collectAsState()
    val synthesisProgress by viewModel.synthesisProgress.collectAsState()
    val generatedAudioPath by viewModel.generatedAudioPath.collectAsState()
    val subtitleEntries = viewModel.subtitleEntries

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var cropRect by remember { mutableStateOf(RectF(0.1f, 0.8f, 0.9f, 0.95f)) }

    LaunchedEffect(cropRect) {
        viewModel.cropRect.value = cropRect
    }

    // Auto navigate to Tab 1 (Dịch) when OCR extraction finishes
    LaunchedEffect(appState) {
        if (appState == AppState.FINISHED && selectedTabIndex == 0) {
            selectedTabIndex = 1
        }
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            uri?.let {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { e.printStackTrace() }
                viewModel.setVideoUri(it)
            }
        }
    )

    val srtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            uri?.let {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { e.printStackTrace() }
                viewModel.importExternalSrtFile(it)
            }
        }
    )

    var selectedOnnxUri by remember { mutableStateOf<Uri?>(null) }
    var selectedTokensUri by remember { mutableStateOf<Uri?>(null) }

    val onnxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            uri?.let {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { e.printStackTrace() }
                selectedOnnxUri = it
                if (selectedTokensUri != null) {
                    viewModel.loadVoiceModel(it, selectedTokensUri!!)
                }
            }
        }
    )

    val tokensLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            uri?.let {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { e.printStackTrace() }
                selectedTokensUri = it
                if (selectedOnnxUri != null) {
                    viewModel.loadVoiceModel(selectedOnnxUri!!, it)
                }
            }
        }
    )

    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlayingAudio by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "HSub V1 - Phụ Đề & Giọng Đọc",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // --- Stepper / TabRow Header ---
        TabRow(
            selectedTabIndex = selectedTabIndex,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = selectedTabIndex == 0,
                onClick = { selectedTabIndex = 0 },
                text = { Text("1. Nguồn", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Movie, contentDescription = "Nguồn Video") }
            )
            Tab(
                selected = selectedTabIndex == 1,
                onClick = { selectedTabIndex = 1 },
                text = { Text("2. Dịch", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Translate, contentDescription = "Dịch Thuật") }
            )
            Tab(
                selected = selectedTabIndex == 2,
                onClick = { selectedTabIndex = 2 },
                text = { Text("3. Đọc giọng", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = "Đọc Giọng") }
            )
            Tab(
                selected = selectedTabIndex == 3,
                onClick = { selectedTabIndex = 3 },
                text = { Text("4. Xuất", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.FileDownload, contentDescription = "Xuất Kết Quả") }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTabIndex) {
                // ==================== TAB 0: NGUỒN ====================
                0 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "BƯỚC 1: CHỌN NGUỒN PHỤ ĐỀ / VIDEO",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { launcher.launch(arrayOf("video/*")) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.VideoFile, contentDescription = "Chọn Video")
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (videoUri == null) "Chọn Video" else "Đổi Video")
                                }

                                OutlinedButton(
                                    onClick = { srtLauncher.launch(arrayOf("text/*", "application/x-subrip", "*/*")) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.FileDownload, contentDescription = "Nhập File SRT")
                                    Spacer(Modifier.width(4.dp))
                                    Text("Nhập File SRT")
                                }
                            }

                            if (videoUri == null && subtitleEntries.isEmpty()) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Info,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Text(
                                            text = "Chưa chọn video hoặc file phụ đề.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "Bấm 'Chọn Video' để trích xuất phụ đề tự động bằng OCR, hoặc 'Nhập File SRT' nếu đã có sẵn.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            if (previewBitmap != null) {
                                Text(
                                    text = "Vẽ vùng chữ nhật bao quanh vị trí xuất hiện phụ đề trong video:",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(previewBitmap!!.width.toFloat() / previewBitmap!!.height.toFloat())
                                        .background(Color.Black, RoundedCornerShape(8.dp))
                                ) {
                                    Image(
                                        bitmap = previewBitmap!!.asImageBitmap(),
                                        contentDescription = "Xem Trước Video",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )

                                    Canvas(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .pointerInput(Unit) {
                                                detectDragGestures(
                                                    onDragStart = { offset ->
                                                        val xPercent = offset.x / size.width
                                                        val yPercent = offset.y / size.height
                                                        cropRect = RectF(xPercent, yPercent, xPercent, yPercent)
                                                    },
                                                    onDrag = { change, _ ->
                                                        change.consume()
                                                        val endXPercent = change.position.x / size.width
                                                        val endYPercent = change.position.y / size.height
                                                        cropRect = RectF(
                                                            minOf(cropRect.left, endXPercent).coerceIn(0f, 1f),
                                                            minOf(cropRect.top, endYPercent).coerceIn(0f, 1f),
                                                            maxOf(cropRect.left, endXPercent).coerceIn(0f, 1f),
                                                            maxOf(cropRect.bottom, endYPercent).coerceIn(0f, 1f)
                                                        )
                                                    }
                                                )
                                            }
                                    ) {
                                        val rectPx = androidx.compose.ui.geometry.Rect(
                                            left = cropRect.left * size.width,
                                            top = cropRect.top * size.height,
                                            right = cropRect.right * size.width,
                                            bottom = cropRect.bottom * size.height
                                        )
                                        drawRect(
                                            color = Color.Red,
                                            topLeft = rectPx.topLeft,
                                            size = rectPx.size,
                                            style = Stroke(width = 4.dp.toPx())
                                        )
                                        drawRect(
                                            color = Color.Red.copy(alpha = 0.2f),
                                            topLeft = rectPx.topLeft,
                                            size = rectPx.size
                                        )
                                    }
                                }

                                Text(
                                    text = "Vùng chọn: Trái:${"%.2f".format(cropRect.left)}, Trên:${"%.2f".format(cropRect.top)}, Phải:${"%.2f".format(cropRect.right)}, Dưới:${"%.2f".format(cropRect.bottom)}",
                                    style = MaterialTheme.typography.labelSmall
                                )

                                Button(
                                    onClick = { viewModel.startProcessing() },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = appState != AppState.PROCESSING
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Trích Xuất")
                                    Spacer(Modifier.width(8.dp))
                                    Text("Bắt Đầu Trích Xuất Phụ Đề Video")
                                }
                            } else if (videoUri != null && appState == AppState.IDLE) {
                                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                                Text("Đang tải hình ảnh xem trước từ video...", modifier = Modifier.align(Alignment.CenterHorizontally))
                            }

                            if (appState == AppState.PROCESSING) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("Đang Trích Xuất Phụ Đề...", style = MaterialTheme.typography.titleSmall)
                                        }

                                        val progressFloat = if (progress.totalFrames > 0) {
                                            progress.currentFrame.toFloat() / progress.totalFrames.toFloat()
                                        } else 0f

                                        LinearProgressIndicator(
                                            progress = { progressFloat },
                                            modifier = Modifier.fillMaxWidth()
                                        )

                                        Text("Khung hình: ${progress.currentFrame} / ${progress.totalFrames}")
                                        Text("Thời gian: ${formatTimeMs(progress.currentTimeMs)} / ${formatTimeMs(progress.totalTimeMs)}")
                                        if (progress.realtimeSpeedX > 0f) {
                                            Text(
                                                "Tốc độ: ${"%.1f".format(progress.realtimeSpeedX)}x | Số lần OCR: ${progress.ocrExecutions}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }

                                        if (progress.textRecognized.isNotBlank()) {
                                            Text(
                                                "Đang nhận diện: ${progress.textRecognized}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }

                            if (subtitleEntries.isNotEmpty()) {
                                AssistChip(
                                    onClick = { selectedTabIndex = 1 },
                                    label = { Text("Đã có ${subtitleEntries.size} câu phụ đề -> Chuyển sang Dịch thuật") },
                                    leadingIcon = { Icon(Icons.Default.Check, contentDescription = null) },
                                    trailingIcon = { Icon(Icons.Default.ArrowForward, contentDescription = null) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // ==================== TAB 1: DỊCH THUẬT ====================
                1 -> {
                    var showGeminiWebModal by remember { mutableStateOf(false) }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "BƯỚC 2: DỊCH THUẬT PHỤ ĐỀ SANG TIẾNG VIỆT",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            val selectedEngine by viewModel.selectedEngine.collectAsState()
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = selectedEngine == "Gemini",
                                    onClick = { viewModel.selectedEngine.value = "Gemini" },
                                    label = { Text("Gemini API") },
                                    leadingIcon = if (selectedEngine == "Gemini") { { Icon(Icons.Default.Check, contentDescription = null) } } else null,
                                    modifier = Modifier.weight(1f)
                                )

                                FilterChip(
                                    selected = selectedEngine == "DeepSeek",
                                    onClick = { viewModel.selectedEngine.value = "DeepSeek" },
                                    label = { Text("DeepSeek API") },
                                    leadingIcon = if (selectedEngine == "DeepSeek") { { Icon(Icons.Default.Check, contentDescription = null) } } else null,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (selectedEngine == "Gemini") {
                                val geminiKey by viewModel.geminiApiKey.collectAsState()
                                val geminiModel by viewModel.geminiModel.collectAsState()

                                OutlinedTextField(
                                    value = geminiKey,
                                    onValueChange = { viewModel.geminiApiKey.value = it },
                                    label = { Text("Gemini API Key") },
                                    placeholder = { Text("Nhập Gemini API Key...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = geminiModel,
                                    onValueChange = { viewModel.geminiModel.value = it },
                                    label = { Text("Gemini Model ID") },
                                    placeholder = { Text("gemini-flash-latest") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            } else {
                                val deepseekKey by viewModel.deepseekApiKey.collectAsState()
                                val deepseekModel by viewModel.deepseekModel.collectAsState()

                                OutlinedTextField(
                                    value = deepseekKey,
                                    onValueChange = { viewModel.deepseekApiKey.value = it },
                                    label = { Text("DeepSeek API Key") },
                                    placeholder = { Text("Nhập DeepSeek API Key...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = deepseekModel,
                                    onValueChange = { viewModel.deepseekModel.value = it },
                                    label = { Text("DeepSeek Model ID") },
                                    placeholder = { Text("deepseek-chat") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            }

                            Button(
                                onClick = { showGeminiWebModal = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Text("ĐĂNG NHẬP / MỞ GEMINI WEB")
                            }

                            if (isTranslating) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }

                            if (translationProgress.isNotBlank()) {
                                AssistChip(
                                    onClick = { },
                                    label = { Text(translationProgress) },
                                    leadingIcon = {
                                        if (translationProgress.startsWith("Lỗi")) {
                                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                        } else {
                                            Icon(Icons.Default.Info, contentDescription = null)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.translateSubtitles() },
                                    modifier = Modifier.weight(1f),
                                    enabled = !isTranslating && subtitleEntries.isNotEmpty()
                                ) {
                                    Text("Dịch Tiếng Việt")
                                }

                                OutlinedButton(
                                    onClick = { viewModel.retranslateFailedEntries() },
                                    modifier = Modifier.weight(1f),
                                    enabled = !isTranslating && subtitleEntries.isNotEmpty()
                                ) {
                                    Text("Dịch lại câu lỗi")
                                }
                            }

                            if (subtitleEntries.isEmpty()) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "Chưa có danh sách phụ đề để dịch.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Hãy chuyển sang Tab 1 'Nguồn' để trích xuất từ video hoặc nhập file SRT.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = "DANH SÁCH CÂU PHỤ ĐỀ (${subtitleEntries.size} CÂU)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 240.dp)
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    subtitleEntries.forEach { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            SelectionContainer {
                                                Text(
                                                    text = "#${item.index}: ${item.text}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }
                                }

                                Button(
                                    onClick = { selectedTabIndex = 2 },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("Chuyển Sang Đọc Giọng TTS ->")
                                }
                            }
                        }
                    }

                    if (showGeminiWebModal) {
                        AlertDialog(
                            onDismissRequest = { showGeminiWebModal = false },
                            confirmButton = {
                                TextButton(onClick = { showGeminiWebModal = false }) {
                                    Text("Đóng")
                                }
                            },
                            title = { Text("Đăng nhập Google / Gemini Web") },
                            text = {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(400.dp)
                                ) {
                                    androidx.compose.ui.viewinterop.AndroidView(
                                        factory = { ctx ->
                                            android.webkit.WebView(ctx).apply {
                                                settings.javaScriptEnabled = true
                                                settings.domStorageEnabled = true
                                                settings.userAgentString =
                                                    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                                                webViewClient = object : android.webkit.WebViewClient() {
                                                    override fun shouldOverrideUrlLoading(
                                                        view: android.webkit.WebView?,
                                                        request: android.webkit.WebResourceRequest?
                                                    ): Boolean = false
                                                }
                                                loadUrl("https://gemini.google.com")
                                            }
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        )
                    }
                }

                // ==================== TAB 2: ĐỌC GIỌNG (TTS) ====================
                2 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "BƯỚC 3: CẤU HÌNH & TỔNG HỢP GIỌNG ĐỌC OFFLINE (SHERPA-ONNX)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onnxLauncher.launch(arrayOf("*/*")) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AudioFile, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = if (selectedOnnxUri != null) "Đã chọn .onnx" else "Chọn file .onnx",
                                        maxLines = 1
                                    )
                                }

                                OutlinedButton(
                                    onClick = { tokensLauncher.launch(arrayOf("*/*")) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AudioFile, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = if (selectedTokensUri != null) "Đã chọn tokens/json" else "Chọn tokens.txt / .onnx.json",
                                        maxLines = 1
                                    )
                                }
                            }

                            AssistChip(
                                onClick = { },
                                label = {
                                    Text(
                                        if (ttsModelReady) "Trạng thái: Đã sẵn sàng giọng đọc sherpa-onnx!"
                                        else "Trạng thái: Giọng đọc chưa nạp (Chọn file .onnx và tokens.txt hoặc .onnx.json để kích hoạt)"
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        if (ttsModelReady) Icons.Default.Check else Icons.Default.Info,
                                        contentDescription = null,
                                        tint = if (ttsModelReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (synthesisProgress.isNotBlank()) {
                                Text(
                                    text = synthesisProgress,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (isSynthesizing) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }

                            Button(
                                onClick = { viewModel.synthesizeSubtitlesToAudio() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = ttsModelReady && !isSynthesizing && subtitleEntries.isNotEmpty()
                            ) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = "Tạo Giọng Đọc")
                                Spacer(Modifier.width(8.dp))
                                Text("Bắt Đầu Tạo Giọng Đọc Phụ Đề")
                            }

                            if (generatedAudioPath != null) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                                Text(
                                    text = "NGHE THỬ BẢN ÂM THANH ĐÃ TẠO",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            try {
                                                if (isPlayingAudio) {
                                                    mediaPlayer?.pause()
                                                    isPlayingAudio = false
                                                } else {
                                                    val audioFile = File(generatedAudioPath!!)
                                                    if (audioFile.exists()) {
                                                        mediaPlayer?.release()
                                                        mediaPlayer = MediaPlayer.create(context, Uri.fromFile(audioFile))
                                                        mediaPlayer?.setOnCompletionListener { isPlayingAudio = false }
                                                        mediaPlayer?.start()
                                                        isPlayingAudio = true
                                                    } else {
                                                        Toast.makeText(context, "Không tìm thấy file audio", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                                Toast.makeText(context, "Lỗi phát audio: ${e.message}", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            if (isPlayingAudio) Icons.Default.Stop else Icons.Default.VolumeUp,
                                            contentDescription = null
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (isPlayingAudio) "Tạm Dừng" else "Nghe Thử")
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            mediaPlayer?.stop()
                                            mediaPlayer?.release()
                                            mediaPlayer = null
                                            isPlayingAudio = false
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Stop, contentDescription = null)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Dừng")
                                    }
                                }

                                Button(
                                    onClick = { selectedTabIndex = 3 },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("Xem & Xuất File Kết Quả ->")
                                }
                            }
                        }
                    }
                }

                // ==================== TAB 3: XUẤT ====================
                3 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "BƯỚC 4: XUẤT PHỤ ĐỀ SRT & FILE ÂM THANH WAV",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            // Summary Info
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "TỔNG QUAN KẾT QUẢ PHÂN TÍCH:",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text("• Tổng số câu phụ đề: ${subtitleEntries.size} câu")
                                    Text("• Nguồn video: ${if (videoUri != null) "Đã chọn" else "Không có"}")
                                    Text("• File âm thanh WAV: ${if (generatedAudioPath != null) "Đã tạo sẵn sàng" else "Chưa tạo"}")
                                }
                            }

                            Button(
                                onClick = { saveAndShareSrt(context, srtContent) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = srtContent.isNotBlank() || subtitleEntries.isNotEmpty()
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = "Tải File SRT")
                                Spacer(Modifier.width(8.dp))
                                Text("Tải / Chia Sẻ File SRT Phụ Đề")
                            }

                            Button(
                                onClick = {
                                    generatedAudioPath?.let { path ->
                                        saveAndShareAudio(context, path)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = generatedAudioPath != null,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(Icons.Default.AudioFile, contentDescription = "Tải File Audio")
                                Spacer(Modifier.width(8.dp))
                                Text("Tải / Chia Sẻ File Âm Thanh (.wav)")
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            OutlinedButton(
                                onClick = {
                                    viewModel.setVideoUri(null)
                                    selectedTabIndex = 0
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Bắt Đầu Lại Mới (Reset)")
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatTimeMs(timeMs: Long): String {
    val totalSeconds = timeMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}

fun saveAndShareSrt(context: Context, srtContent: String) {
    try {
        val file = File(context.cacheDir, "subtitles.srt")
        val writer = FileWriter(file)
        writer.write(srtContent)
        writer.close()

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/x-subrip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(intent, "Lưu/Chia sẻ File SRT"))
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Lỗi khi lưu/chia sẻ file SRT: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

fun saveAndShareAudio(context: Context, audioPath: String) {
    try {
        val srcFile = File(audioPath)
        if (!srcFile.exists()) {
            Toast.makeText(context, "Chưa tìm thấy file audio", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            srcFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Lưu/Chia sẻ File Âm Thanh WAV"))
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Lỗi khi lưu/chia sẻ file audio: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
