package com.example

import android.app.Application
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppState {
    IDLE, PROCESSING, FINISHED
}

class HSubViewModel(application: Application) : AndroidViewModel(application) {

    private val videoProcessor = VideoProcessor(application)
    private val timelineBuilder = TimelineBuilder()
    
    private val _appState = MutableStateFlow(AppState.IDLE)
    val appState: StateFlow<AppState> = _appState.asStateFlow()

    private val _progress = MutableStateFlow(ProcessingProgress(0, 0, 0L, 0L, ""))
    val progress: StateFlow<ProcessingProgress> = _progress.asStateFlow()

    private val _videoUri = MutableStateFlow<Uri?>(null)
    val videoUri: StateFlow<Uri?> = _videoUri.asStateFlow()

    private val _previewBitmap = MutableStateFlow<android.graphics.Bitmap?>(null)
    val previewBitmap: StateFlow<android.graphics.Bitmap?> = _previewBitmap.asStateFlow()

    private val _srtContent = MutableStateFlow("")
    val srtContent: StateFlow<String> = _srtContent.asStateFlow()

    private val _translationProgress = MutableStateFlow<String>("")
    val translationProgress: StateFlow<String> = _translationProgress.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    // --- Offline sherpa-onnx TTS State ---
    private val _ttsModelReady = MutableStateFlow(false)
    val ttsModelReady: StateFlow<Boolean> = _ttsModelReady.asStateFlow()

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing.asStateFlow()

    private val _synthesisProgress = MutableStateFlow("")
    val synthesisProgress: StateFlow<String> = _synthesisProgress.asStateFlow()

    private val _generatedAudioPath = MutableStateFlow<String?>(null)
    val generatedAudioPath: StateFlow<String?> = _generatedAudioPath.asStateFlow()

    private var currentEntries: List<SubtitleEntry> = emptyList()
    val subtitleEntries: List<SubtitleEntry> get() = currentEntries

    val geminiApiKey = MutableStateFlow("")
    val geminiModel = MutableStateFlow("gemini-1.5-flash-latest")
    val deepseekApiKey = MutableStateFlow("")
    val deepseekModel = MutableStateFlow("deepseek-chat")
    val selectedEngine = MutableStateFlow("Gemini")

    // Default crop rect: bottom 20% of the screen horizontally centered (10% to 90%)
    val cropRect = MutableStateFlow(RectF(0.1f, 0.8f, 0.9f, 0.95f))

    fun setVideoUri(uri: Uri?) {
        _videoUri.value = uri
        _appState.value = AppState.IDLE
        _srtContent.value = ""
        _progress.value = ProcessingProgress(0, 0, 0L, 0L, "")
        
        if (uri == null) {
            _previewBitmap.value = null
            return
        }

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val bmp = PreviewExtractor.getPreviewFrame(getApplication(), uri)
            _previewBitmap.value = bmp
        }
    }

    fun startProcessing() {
        val uri = _videoUri.value ?: return
        _appState.value = AppState.PROCESSING
        
        viewModelScope.launch {
            videoProcessor.processVideo(uri, cropRect.value, timelineBuilder).collect { prog ->
                _progress.value = prog
            }
            
            // Pipeline finished -> Get finalized timeline and generate SRT
            val rawResults = timelineBuilder.finalizeTimeline()
            currentEntries = SrtGenerator.generateEntries(rawResults)
            val srt = SrtGenerator.entriesToSrt(currentEntries)
            _srtContent.value = srt
            _appState.value = AppState.FINISHED
            Log.d("HSubViewModel", "OCR Engine Pipeline finished successfully")
        }
    }

    fun importExternalSrtFile(uri: Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val inputStream = getApplication<Application>().contentResolver.openInputStream(uri)
                val srtText = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (srtText.isNotBlank()) {
                    val entries = SrtGenerator.parseSrt(srtText)
                    if (entries.isNotEmpty()) {
                        currentEntries = entries
                        _srtContent.value = SrtGenerator.entriesToSrt(entries)
                        _appState.value = AppState.FINISHED
                        _translationProgress.value = "Đã nhập file SRT ngoài (${entries.size} câu phụ đề)!"
                        Log.d("HSubViewModel", "Imported external SRT file: ${entries.size} entries")
                    } else {
                        _translationProgress.value = "File SRT không có cấu trúc hợp lệ"
                    }
                }
            } catch (e: Exception) {
                Log.e("HSubViewModel", "Failed to import external SRT file", e)
                _translationProgress.value = "Lỗi khi nhập file SRT: ${e.message}"
            }
        }
    }

    fun translateSubtitles() {
        if (currentEntries.isEmpty() || _isTranslating.value) return
        _isTranslating.value = true
        _translationProgress.value = "Đang bắt đầu dịch sang Tiếng Việt (${selectedEngine.value})..."
        
        viewModelScope.launch {
            try {
                val translatedEntries = if (selectedEngine.value == "DeepSeek") {
                    DeepseekTranslator.translateSubtitles(
                        apiKey = deepseekApiKey.value,
                        model = deepseekModel.value,
                        entries = currentEntries
                    ) { current, total ->
                        _translationProgress.value = "Đã dịch (DeepSeek) $current / $total câu phụ đề..."
                    }
                } else {
                    GeminiTranslator.translateSubtitles(
                        apiKey = geminiApiKey.value,
                        model = geminiModel.value,
                        entries = currentEntries
                    ) { current, total ->
                        _translationProgress.value = "Đã dịch (Gemini) $current / $total câu phụ đề..."
                    }
                }
                
                currentEntries = translatedEntries
                _srtContent.value = SrtGenerator.entriesToSrt(translatedEntries)
                _translationProgress.value = "Dịch Hoàn Tất! Đã tạo file phụ đề Tiếng Việt."
                Log.d("HSubViewModel", "Vietnamese SRT Generated successfully with engine ${selectedEngine.value}")
            } catch (e: Exception) {
                _translationProgress.value = "Lỗi dịch thuật: ${e.message}"
                Log.e("HSubViewModel", "Translation failed", e)
            } finally {
                _isTranslating.value = false
            }
        }
    }

    fun retranslateFailedEntries() {
        if (currentEntries.isEmpty() || _isTranslating.value) return
        val chineseRegex = Regex("[\\u4E00-\\u9FFF]")
        val failed = currentEntries.filter { chineseRegex.containsMatchIn(it.text) }
        if (failed.isEmpty()) {
            _translationProgress.value = "Tất cả các câu đã được dịch hoàn chỉnh, không có câu lỗi nào!"
            return
        }

        _isTranslating.value = true
        _translationProgress.value = "Đang dịch lại ${failed.size} câu chưa dịch xong..."

        viewModelScope.launch {
            try {
                val retranslated = if (selectedEngine.value == "DeepSeek") {
                    DeepseekTranslator.translateSubtitles(
                        apiKey = deepseekApiKey.value,
                        model = deepseekModel.value,
                        entries = failed
                    ) { current, total ->
                        _translationProgress.value = "Đang dịch lại (DeepSeek) $current / $total câu lỗi..."
                    }
                } else {
                    GeminiTranslator.translateSubtitles(
                        apiKey = geminiApiKey.value,
                        model = geminiModel.value,
                        entries = failed
                    ) { current, total ->
                        _translationProgress.value = "Đang dịch lại (Gemini) $current / $total câu lỗi..."
                    }
                }

                val resultMap = retranslated.associateBy { it.index }
                currentEntries = currentEntries.map { resultMap[it.index] ?: it }
                _srtContent.value = SrtGenerator.entriesToSrt(currentEntries)
                _translationProgress.value = "Đã dịch bổ sung ${retranslated.size} câu lỗi thành công!"
            } catch (e: Exception) {
                _translationProgress.value = "Lỗi khi dịch lại: ${e.message}"
            } finally {
                _isTranslating.value = false
            }
        }
    }

    // --- Offline TTS Functions ---
    fun loadVoiceModel(modelUri: Uri, tokensUri: Uri, dataDirUri: Uri? = null) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                _synthesisProgress.value = "Đang chuẩn bị nạp giọng đọc..."
                val context = getApplication<Application>()
                
                // Copy selected files to filesDir
                val modelFile = java.io.File(context.filesDir, "model.onnx")
                val tokensFile = java.io.File(context.filesDir, "tokens.txt")
                
                context.contentResolver.openInputStream(modelUri)?.use { input ->
                    java.io.FileOutputStream(modelFile).use { output -> input.copyTo(output) }
                }

                // Process second file: can be tokens.txt OR .onnx.json (Piper config)
                val secondFileContent = context.contentResolver.openInputStream(tokensUri)?.use { input ->
                    input.bufferedReader(Charsets.UTF_8).readText()
                } ?: ""

                val trimmed = secondFileContent.trimStart()
                if (trimmed.startsWith("{") && trimmed.contains("phoneme_id_map")) {
                    try {
                        val json = org.json.JSONObject(secondFileContent)
                        if (json.has("phoneme_id_map")) {
                            val map = json.getJSONObject("phoneme_id_map")
                            val sb = StringBuilder()
                            val keys = map.keys()
                            while (keys.hasNext()) {
                                val symbol = keys.next()
                                if (map.isNull(symbol)) continue
                                val id = if (map.optJSONArray(symbol) != null) {
                                    val arr = map.getJSONArray(symbol)
                                    if (arr.length() > 0) arr.getInt(0) else -1
                                } else {
                                    map.optInt(symbol, -1)
                                }
                                if (id >= 0) {
                                    sb.append("$symbol $id\n")
                                }
                            }
                            tokensFile.writeText(sb.toString(), Charsets.UTF_8)
                            Log.i("HSubViewModel", "Generated tokens.txt from Piper .onnx.json successfully")
                        } else {
                            tokensFile.writeText(secondFileContent, Charsets.UTF_8)
                        }
                    } catch (e: Exception) {
                        Log.w("HSubViewModel", "Error parsing json phoneme_id_map: ${e.message}, falling back to raw copy")
                        tokensFile.writeText(secondFileContent, Charsets.UTF_8)
                    }
                } else {
                    tokensFile.writeText(secondFileContent, Charsets.UTF_8)
                }

                // Ensure espeak-ng-data directory in filesDir
                val espeakDir = java.io.File(context.filesDir, "espeak-ng-data")
                if (!espeakDir.exists()) {
                    espeakDir.mkdirs()
                    try {
                        copyAssetDir(context.assets, "espeak-ng-data", espeakDir)
                    } catch (e: Exception) {
                        Log.w("HSubViewModel", "No espeak-ng-data found in assets: ${e.message}")
                    }
                }

                TtsEngine.loadVoice(
                    modelPath = modelFile.absolutePath,
                    tokensPath = tokensFile.absolutePath,
                    dataDirPath = espeakDir.absolutePath
                )

                _ttsModelReady.value = true
                _synthesisProgress.value = "Đã nạp giọng đọc sherpa-onnx thành công!"
            } catch (e: Exception) {
                Log.e("HSubViewModel", "Lỗi nạp voice model sherpa-onnx", e)
                _synthesisProgress.value = "Lỗi nạp voice model: ${e.message}"
                _ttsModelReady.value = false
            }
        }
    }

    private fun copyAssetDir(assetManager: android.content.res.AssetManager, path: String, outDir: java.io.File) {
        val files = assetManager.list(path) ?: return
        if (files.isEmpty()) {
            assetManager.open(path).use { input ->
                java.io.FileOutputStream(outDir).use { output -> input.copyTo(output) }
            }
        } else {
            outDir.mkdirs()
            for (f in files) {
                copyAssetDir(assetManager, "$path/$f", java.io.File(outDir, f))
            }
        }
    }

    fun synthesizeSubtitlesToAudio() {
        if (currentEntries.isEmpty() || _isSynthesizing.value) return
        _isSynthesizing.value = true
        _synthesisProgress.value = "Đang bắt đầu đọc..."

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val totalCount = currentEntries.size
                val clips = mutableListOf<Pair<SubtitleEntry, GeneratedAudio>>()

                for ((idx, entry) in currentEntries.withIndex()) {
                    _synthesisProgress.value = "Đang đọc câu ${idx + 1}/$totalCount"
                    val audio = TtsEngine.synthesize(entry.text)
                    clips.add(Pair(entry, audio))
                }

                if (clips.isEmpty()) {
                    _synthesisProgress.value = "Không có phụ đề nào để tổng hợp."
                    _isSynthesizing.value = false
                    return@launch
                }

                _synthesisProgress.value = "Đang xử lý ghép trục thời gian..."
                val sampleRate = clips.first().second.sampleRate

                var maxEndTimeMs = 0L
                for (clip in clips) {
                    val entry = clip.first
                    val audioDurationMs = (clip.second.samples.size * 1000L) / sampleRate
                    val calculatedEnd = entry.startTimeMs + audioDurationMs
                    if (calculatedEnd > maxEndTimeMs) maxEndTimeMs = calculatedEnd
                    if (entry.endTimeMs > maxEndTimeMs) maxEndTimeMs = entry.endTimeMs
                }

                val totalSamples = ((maxEndTimeMs * sampleRate) / 1000L).toInt().coerceAtLeast(sampleRate)
                var masterSamples = FloatArray(totalSamples)

                for (i in 0 until clips.size) {
                    val (entry, audio) = clips[i]
                    val startSampleIdx = ((entry.startTimeMs * sampleRate) / 1000L).toInt()

                    if (i < clips.size - 1) {
                        val nextEntry = clips[i + 1].first
                        val audioEndMs = entry.startTimeMs + ((audio.samples.size * 1000L) / sampleRate)
                        if (audioEndMs > nextEntry.startTimeMs) {
                            Log.w("HSubViewModel", "Cảnh báo: Audio câu #${entry.index} ($audioEndMs ms) kéo dài đè nhẹ qua câu #${nextEntry.index} (${nextEntry.startTimeMs} ms)")
                        }
                    }

                    val requiredSize = startSampleIdx + audio.samples.size
                    if (requiredSize > masterSamples.size) {
                        masterSamples = masterSamples.copyOf(requiredSize)
                    }

                    for (sIdx in audio.samples.indices) {
                        val targetIdx = startSampleIdx + sIdx
                        masterSamples[targetIdx] += audio.samples[sIdx]
                    }
                }

                val wavFile = java.io.File(getApplication<Application>().cacheDir, "hsub_synthesized.wav")
                writeWavFile(wavFile, masterSamples, sampleRate)

                _generatedAudioPath.value = wavFile.absolutePath
                _synthesisProgress.value = "Tạo file âm thanh hoàn tất! (${wavFile.name})"
                Log.i("HSubViewModel", "Audio WAV generated successfully: ${wavFile.length()} bytes")
            } catch (e: Exception) {
                Log.e("HSubViewModel", "Lỗi tổng hợp audio WAV", e)
                _synthesisProgress.value = "Lỗi tổng hợp: ${e.message}"
            } finally {
                _isSynthesizing.value = false
            }
        }
    }

    private fun writeWavFile(file: java.io.File, samples: FloatArray, sampleRate: Int) {
        if (samples.isEmpty()) return

        var maxAbs = 0.0f
        for (s in samples) {
            val absVal = kotlin.math.abs(s)
            if (absVal > maxAbs) maxAbs = absVal
        }

        Log.i("HSubViewModel", "WAV generation: ${samples.size} samples, max amplitude = $maxAbs")

        val pcmBytes = ByteArray(samples.size * 2)
        val buffer = java.nio.ByteBuffer.wrap(pcmBytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)

        val scaleFactor = when {
            maxAbs == 0.0f -> 0.0f
            maxAbs > 1.0f -> 32767.0f / maxAbs
            else -> 0.95f * 32767.0f / maxAbs
        }

        for (s in samples) {
            val scaled = s * scaleFactor
            val clamped = scaled.coerceIn(-32768.0f, 32767.0f)
            val pcmShort = clamped.toInt().toShort()
            buffer.putShort(pcmShort)
        }

        java.io.FileOutputStream(file).use { out ->
            val totalDataLen = pcmBytes.size + 36
            val header = ByteArray(44)
            val hBuf = java.nio.ByteBuffer.wrap(header).order(java.nio.ByteOrder.LITTLE_ENDIAN)

            hBuf.put("RIFF".toByteArray())
            hBuf.putInt(totalDataLen)
            hBuf.put("WAVE".toByteArray())
            hBuf.put("fmt ".toByteArray())
            hBuf.putInt(16)
            hBuf.putShort(1.toShort())
            hBuf.putShort(1.toShort())
            hBuf.putInt(sampleRate)
            hBuf.putInt(sampleRate * 2)
            hBuf.putShort(2.toShort())
            hBuf.putShort(16.toShort())
            hBuf.put("data".toByteArray())
            hBuf.putInt(pcmBytes.size)

            out.write(header)
            out.write(pcmBytes)
        }
    }
}
