package com.example

import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.TimeUnit

@Serializable
data class DeepseekMessage(
    val role: String,
    val content: String
)

@Serializable
data class DeepseekRequest(
    val model: String = "deepseek-chat",
    val messages: List<DeepseekMessage>,
    val temperature: Float = 0.3f
)

@Serializable
data class DeepseekChoice(
    val message: DeepseekMessage? = null
)

@Serializable
data class DeepseekResponse(
    val choices: List<DeepseekChoice>? = null
)

interface DeepseekApiService {
    @POST("v1/chat/completions")
    suspend fun generateContent(
        @Header("Authorization") authHeader: String,
        @Body request: DeepseekRequest
    ): DeepseekResponse
}

object DeepseekRetrofitClient {
    private const val BASE_URL = "https://api.deepseek.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: DeepseekApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; explicitNulls = false }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(DeepseekApiService::class.java)
    }
}

object DeepseekTranslator {

    private val translationMemory = java.util.concurrent.ConcurrentHashMap<String, String>()

    private val systemPrompt = """
Vietnamese Subtitle Translation & TTS Optimization Prompt

You are an expert Chinese→Vietnamese subtitle translator and Vietnamese subtitle editor specialized in Text-To-Speech (TTS).

Your goal is to translate OCR subtitles into natural Vietnamese and then optimize each subtitle so it perfectly fits its available speaking duration.

The output will be used directly by an automatic Vietnamese TTS engine.

---
Primary Tasks
For EVERY subtitle:
1. Correct obvious OCR mistakes before translation whenever the intended Chinese sentence is clear.
2. Translate into fluent, natural Vietnamese.
3. Add punctuation naturally.
4. Optimize the translated subtitle for Vietnamese TTS.
5. Ensure every subtitle fits its own maxLength.

---
Translation Rules
Translate EVERY subtitle.
Never leave Chinese text untranslated.
Never skip any subtitle.
Never merge different subtitle IDs.
Never split one subtitle into multiple subtitles.
Keep original subtitle order.
Do NOT explain.
Do NOT summarize unless required by maxLength.

---
JSON Rules
Return ONLY valid JSON array:
[
  {
    "id": 1,
    "text": "câu dịch tiếng Việt tự nhiên ngắn gọn"
  }
]
    """.trimIndent()

    suspend fun translateSubtitles(
        apiKey: String,
        model: String = "deepseek-chat",
        entries: List<SubtitleEntry>,
        onProgress: (Int, Int) -> Unit
    ): List<SubtitleEntry> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            throw Exception("DeepSeek API Key không được để trống. Vui lòng nhập API Key.")
        }

        val effectiveModel = if (model.isNotBlank()) model else "deepseek-chat"
        Log.d("DeepseekTranslator", "Translation Started. Total subtitles: ${entries.size}, Model: $effectiveModel")

        val resultMap = java.util.concurrent.ConcurrentHashMap<Int, String>()
        val uncompressedEntries = mutableListOf<SubtitleEntry>()

        var cacheHits = 0
        for (entry in entries) {
            val cached = translationMemory[entry.text.trim()]
            if (cached != null) {
                resultMap[entry.index] = cached
                cacheHits++
            } else {
                uncompressedEntries.add(entry)
            }
        }

        if (uncompressedEntries.isNotEmpty()) {
            val batchSize = 25
            val batches = uncompressedEntries.chunked(batchSize)
            val completedCount = java.util.concurrent.atomic.AtomicInteger(cacheHits)

            val semaphore = kotlinx.coroutines.sync.Semaphore(4)
            kotlinx.coroutines.coroutineScope {
                val jobs = batches.map { batch ->
                    async {
                        semaphore.withPermit {
                            val translatedMap = translateBatch(apiKey.trim(), effectiveModel, batch)
                            for ((id, text) in translatedMap) {
                                resultMap[id] = text
                                val sourceEntry = batch.find { it.index == id }
                                if (sourceEntry != null && sourceEntry.text.isNotBlank()) {
                                    translationMemory[sourceEntry.text.trim()] = text
                                }
                            }
                            val count = completedCount.addAndGet(batch.size)
                            onProgress(minOf(count, entries.size), entries.size)
                        }
                    }
                }
                jobs.awaitAll()
            }
        } else {
            onProgress(entries.size, entries.size)
        }

        val finalEntries = entries.map { entry ->
            val text = resultMap[entry.index] ?: entry.text
            entry.copy(text = text)
        }

        // Validate results (Requirement A3)
        val chineseRegex = Regex("[\\u4E00-\\u9FFF]")
        var untranslatedCount = 0
        for (e in finalEntries) {
            if (chineseRegex.containsMatchIn(e.text)) {
                untranslatedCount++
            }
        }

        if (finalEntries.isNotEmpty() && (untranslatedCount.toDouble() / finalEntries.size.toDouble()) > 0.20) {
            throw Exception("Dịch DeepSeek thất bại: $untranslatedCount / ${finalEntries.size} câu phụ đề chưa được dịch. Vui lòng kiểm tra API Key hoặc kết nối mạng.")
        }

        return@withContext finalEntries
    }

    private suspend fun translateBatch(
        apiKey: String,
        model: String,
        batch: List<SubtitleEntry>
    ): Map<Int, String> {
        val promptBuilder = StringBuilder("Please translate the following subtitles into Vietnamese (Return JSON array):\n")
        for (entry in batch) {
            val durationMs = entry.endTimeMs - entry.startTimeMs
            val maxLength = ((durationMs / 1000.0) * 15).toInt().coerceAtLeast(15)
            promptBuilder.append("ID: ${entry.index} | Duration: ${durationMs}ms | MaxLength: ${maxLength} chars | Text: ${entry.text}\n")
        }

        val request = DeepseekRequest(
            model = model,
            messages = listOf(
                DeepseekMessage(role = "system", content = systemPrompt),
                DeepseekMessage(role = "user", content = promptBuilder.toString())
            )
        )

        var retryCount = 0
        val maxRetries = 2

        while (retryCount <= maxRetries) {
            try {
                if (retryCount > 0) {
                    delay(1500L * retryCount)
                }
                val response = DeepseekRetrofitClient.service.generateContent("Bearer $apiKey", request)
                val rawText = response.choices?.firstOrNull()?.message?.content ?: "[]"

                var jsonStr = rawText
                if (jsonStr.contains("```json")) {
                    jsonStr = jsonStr.substringAfter("```json").substringBeforeLast("```").trim()
                } else if (jsonStr.contains("```")) {
                    jsonStr = jsonStr.substringAfter("```").substringBeforeLast("```").trim()
                }

                val parsedArray = Json { ignoreUnknownKeys = true }.decodeFromString<List<TranslatedSubtitle>>(jsonStr)
                val resultMap = mutableMapOf<Int, String>()
                for (entry in batch) {
                    val translatedText = parsedArray.find { it.id == entry.index }?.text
                    if (!translatedText.isNullOrBlank()) {
                        resultMap[entry.index] = translatedText
                    } else {
                        resultMap[entry.index] = entry.text
                    }
                }
                return resultMap
            } catch (e: Exception) {
                Log.w("DeepseekTranslator", "Batch failed (attempt ${retryCount + 1}): ${e.message}")
                retryCount++
            }
        }

        val fallbackMap = mutableMapOf<Int, String>()
        for (entry in batch) {
            fallbackMap[entry.index] = entry.text
        }
        return fallbackMap
    }
}
