package com.example

import android.graphics.Bitmap

/**
 * Represents a raw OCR frame result produced by the OCR pipeline.
 */
data class RawOcrResult(
    val frameNumber: Int,
    val startTimeMs: Long,
    var endTimeMs: Long,
    val text: String,
    val confidence: Float = 1.0f,
    val wasOcrExecuted: Boolean = true
)

/**
 * Standard subtitle entry structure for SRT generation.
 */
data class SubtitleEntry(
    val index: Int,
    val startTimeMs: Long,
    var endTimeMs: Long,
    val text: String
)

/**
 * Comprehensive processing progress and pipeline telemetry.
 */
data class ProcessingProgress(
    val currentFrame: Int,
    val totalFrames: Int,
    val currentTimeMs: Long,
    val totalTimeMs: Long,
    val textRecognized: String = "",
    val ocrExecutions: Int = 0,
    val skippedOcrCalls: Int = 0,
    val fps: Float = 0f,
    val realtimeSpeedX: Float = 0f,
    val estimatedTimeRemainingMs: Long = 0L,
    val currentStepMs: Long = 300L
)

/**
 * Packet passed through the pipeline stages from Decoder to Comparator to OCR.
 */
data class FramePacket(
    val frameNumber: Int,
    val timestampMs: Long,
    val croppedBitmap: Bitmap,
    val stepMs: Long
)
